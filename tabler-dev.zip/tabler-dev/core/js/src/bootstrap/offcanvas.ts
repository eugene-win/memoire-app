/**
 * --------------------------------------------------------------------------
 * Bootstrap offcanvas.ts
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 * --------------------------------------------------------------------------
 */

import BaseComponent from './base-component'
import EventHandler from './dom/event-handler'
import SelectorEngine from './dom/selector-engine'
import Backdrop from './util/backdrop'
import { enableDismissTrigger } from './util/component-functions'
import FocusTrap from './util/focustrap'
import { defineJQueryPlugin, getFocusReturnTarget, isDisabled, restoreFocus } from './util/index'
import ScrollBarHelper from './util/scrollbar'
import type { ComponentConfig as BaseComponentConfig, JQueryCollectionLike } from './types'

/**
 * Constants
 */

const NAME = 'offcanvas'
const DATA_KEY = 'bs.offcanvas'
const EVENT_KEY = `.${DATA_KEY}`
const DATA_API_KEY = '.data-api'
const EVENT_LOAD_DATA_API = `load${EVENT_KEY}${DATA_API_KEY}`
const ESCAPE_KEY = 'Escape'

const CLASS_NAME_SHOW = 'show'
const CLASS_NAME_SHOWING = 'showing'
const CLASS_NAME_HIDING = 'hiding'
const CLASS_NAME_BACKDROP = 'offcanvas-backdrop'
const OPEN_SELECTOR = '.offcanvas.show'

const EVENT_SHOW = `show${EVENT_KEY}`
const EVENT_SHOWN = `shown${EVENT_KEY}`
const EVENT_HIDE = `hide${EVENT_KEY}`
const EVENT_HIDE_PREVENTED = `hidePrevented${EVENT_KEY}`
const EVENT_HIDDEN = `hidden${EVENT_KEY}`
const EVENT_RESIZE = `resize${EVENT_KEY}`
const EVENT_CLICK_DATA_API = `click${EVENT_KEY}${DATA_API_KEY}`
const EVENT_KEYDOWN_DISMISS = `keydown.dismiss${EVENT_KEY}`

const SELECTOR_DATA_TOGGLE = '[data-bs-toggle="offcanvas"], [data-tblr-toggle="offcanvas"]'

type ComponentConfig = {
  backdrop: boolean | 'static'
  keyboard: boolean
  scroll: boolean
}

type ComponentConfigInput = Partial<ComponentConfig> & Record<string, unknown>

const Default: ComponentConfig = {
  backdrop: true,
  keyboard: true,
  scroll: false,
}

const DefaultType: Record<keyof ComponentConfig, string> = {
  backdrop: '(boolean|string)',
  keyboard: 'boolean',
  scroll: 'boolean',
}

/**
 * Class definition
 */

class Offcanvas extends BaseComponent {
  declare _element: HTMLElement
  declare _config: ComponentConfig
  _isShown: boolean
  _backdrop: Backdrop
  _focustrap: FocusTrap
  _returnFocusTarget: HTMLElement | SVGElement | null

  constructor(element: HTMLElement | string, config?: ComponentConfigInput) {
    super(element, config)

    this._isShown = false
    this._returnFocusTarget = null
    this._backdrop = this._initializeBackDrop()
    this._focustrap = this._initializeFocusTrap()
    this._addEventListeners()
  }

  static get Default(): ComponentConfig {
    return Default
  }

  static get DefaultType(): Record<keyof ComponentConfig, string> {
    return DefaultType
  }

  static get NAME(): string {
    return NAME
  }

  toggle(relatedTarget?: HTMLElement): void {
    return this._isShown ? this.hide() : this.show(relatedTarget)
  }

  show(relatedTarget?: HTMLElement): void {
    if (this._isShown) {
      return
    }

    const showEvent = EventHandler.trigger(this._element, EVENT_SHOW, { relatedTarget })

    if (showEvent?.defaultPrevented) {
      return
    }

    this._returnFocusTarget = getFocusReturnTarget(relatedTarget, this._element)
    this._isShown = true
    this._backdrop.show()

    if (!this._config.scroll) {
      new ScrollBarHelper().hide()
    }

    this._element.setAttribute('aria-modal', 'true')
    this._element.setAttribute('role', 'dialog')
    this._element.classList.add(CLASS_NAME_SHOWING)

    const completeCallBack = () => {
      if (!this._config.scroll || this._config.backdrop) {
        this._focustrap.activate()
      }

      this._element.classList.add(CLASS_NAME_SHOW)
      this._element.classList.remove(CLASS_NAME_SHOWING)
      EventHandler.trigger(this._element, EVENT_SHOWN, { relatedTarget })
    }

    this._queueCallback(completeCallBack, this._element, true)
  }

  hide(): void {
    if (!this._isShown) {
      return
    }

    const hideEvent = EventHandler.trigger(this._element, EVENT_HIDE)

    if (hideEvent?.defaultPrevented) {
      return
    }

    this._focustrap.deactivate()
    this._element.blur()
    this._isShown = false
    this._element.classList.add(CLASS_NAME_HIDING)
    this._backdrop.hide()

    const element = this._element
    const returnFocusTarget = this._returnFocusTarget
    this._returnFocusTarget = null

    const completeCallback = () => {
      this._element.classList.remove(CLASS_NAME_SHOW, CLASS_NAME_HIDING)
      this._element.removeAttribute('aria-modal')
      this._element.removeAttribute('role')

      if (!this._config.scroll) {
        new ScrollBarHelper().reset()
      }

      EventHandler.trigger(element, EVENT_HIDDEN)

      if (!(Offcanvas.getInstance(element) as Offcanvas | null)?._isShown) {
        restoreFocus(returnFocusTarget, element)
      }
    }

    this._queueCallback(completeCallback, this._element, true)
  }

  dispose(): void {
    this._backdrop.dispose()
    this._focustrap.deactivate()
    super.dispose()
  }

  _initializeBackDrop(): Backdrop {
    const clickCallback = () => {
      if (this._config.backdrop === 'static') {
        EventHandler.trigger(this._element, EVENT_HIDE_PREVENTED)
        return
      }

      this.hide()
    }

    const isBackdropVisible = Boolean(this._config.backdrop)

    return new Backdrop({
      className: CLASS_NAME_BACKDROP,
      isVisible: isBackdropVisible,
      isAnimated: true,
      rootElement: this._element.parentNode as HTMLElement,
      clickCallback: isBackdropVisible ? clickCallback : null,
    })
  }

  _initializeFocusTrap(): FocusTrap {
    return new FocusTrap({
      trapElement: this._element,
    })
  }

  _addEventListeners(): void {
    EventHandler.on(this._element, EVENT_KEYDOWN_DISMISS, (event: Event) => {
      if ((event as KeyboardEvent).key !== ESCAPE_KEY) {
        return
      }

      if (this._config.keyboard) {
        this.hide()
        return
      }

      EventHandler.trigger(this._element, EVENT_HIDE_PREVENTED)
    })
  }

  static jQueryInterface(this: JQueryCollectionLike, config?: unknown): unknown {
    return this.each(function (this: HTMLElement) {
      const data = Offcanvas.getOrCreateInstance(this, config as BaseComponentConfig) as unknown as Record<string, (arg?: unknown) => unknown>

      if (typeof config !== 'string') {
        return
      }

      if (data[config] === undefined || config.startsWith('_') || config === 'constructor') {
        throw new TypeError(`No method named "${config}"`)
      }

      data[config](this)
    })
  }
}

/**
 * Data API implementation
 */

EventHandler.on(document, EVENT_CLICK_DATA_API, SELECTOR_DATA_TOGGLE, function (this: HTMLElement, event: Event) {
  const target = SelectorEngine.getElementFromSelector(this)

  if (['A', 'AREA'].includes(this.tagName)) {
    event.preventDefault()
  }

  if (!target) {
    return
  }

  if (isDisabled(this)) {
    return
  }

  const alreadyOpen = SelectorEngine.findOne(OPEN_SELECTOR)
  if (alreadyOpen && alreadyOpen !== target) {
    ;(Offcanvas.getInstance(alreadyOpen) as Offcanvas).hide()
  }

  const data = Offcanvas.getOrCreateInstance(target) as Offcanvas
  data.toggle(this)
})

EventHandler.on(window, EVENT_LOAD_DATA_API, () => {
  for (const selector of SelectorEngine.find(OPEN_SELECTOR)) {
    ;(Offcanvas.getOrCreateInstance(selector) as Offcanvas).show()
  }
})

EventHandler.on(window, EVENT_RESIZE, () => {
  for (const element of SelectorEngine.find('[aria-modal][class*=show][class*=offcanvas-]')) {
    if (getComputedStyle(element).position !== 'fixed') {
      ;(Offcanvas.getOrCreateInstance(element) as Offcanvas).hide()
    }
  }
})

enableDismissTrigger(Offcanvas, 'hide', '.offcanvas, .offcanvas-sm, .offcanvas-md, .offcanvas-lg, .offcanvas-xl, .offcanvas-xxl')

defineJQueryPlugin(Offcanvas)

export default Offcanvas
