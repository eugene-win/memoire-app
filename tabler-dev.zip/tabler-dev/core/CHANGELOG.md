# @tabler/core

## 1.7.5

### Patch Changes

- 4ccb046: Fixed `CountUp` losing its end value on `dispose()` and ignoring `separator` and `decimal` in the source text.
- 986dabc: Fixed a `Datepicker` button trigger opening on focus and closing again on the click that follows.
- a00cc81: Fixed a `Datepicker` inside a `.modal` or `.offcanvas` closing before a click on a day lands.
- 3cb0195: Fixed an inline `Datepicker` keeping the theme it was created with.
- e1c9a3e: Fixed `Datepicker` swapping the day and month of a localized initial value.
- f83a6eb: Fixed `Datepicker` not updating the bound input and the selection when a date is typed or pasted into the field.
- 6d247e5: Fixed one invalid `nav-overflow` element stopping the rest of the `tabler.js` bundle.
- 873ca3b: Fixed keyboard navigation of tabs inside `nav-overflow` and a stale active item in its More menu.
- 5dd7b14: Fixed `NumberInput` ignoring the next click after a hold that reached a bound or ended outside the button.
- b073d67: Fixed `NumberInput` not firing `change.bs.numberInput` for a typed value, and Home/End editing a readonly field.
- 17c8b74: Fixed `OtpInput` losing characters when a pasted code contains separators.
- b8da7e9: Fixed sidebar icons sitting 2px off center in `.nav-link-icon`, visible in the folded sidebar.
- 457a15c: Fixed folded sidebar dropdowns written with `data-tblr-toggle` not closing on an outside click.
- 08652fa: Fixed `data-bs-toggle="toast"` triggers throwing after the toast is created again and following the link `href`.
- cb1df03: Fixed `VectorMap` staying broken when its map data loads after the first initialisation.
- 7c2dfff: Fixed `VectorMap` panning on hover after a pointer was released outside the map.
- 81c2442: Fixed the map `library` option so a `data-bs-library` attribute only loads the module from the same origin as the page.
- b0a29f9: Updated the `masonry` page library to ship from `masonry-layout` in `dist/libs/` instead of a cdnjs URL.
- b0a29f9: Added minified `maps/world.min.js` and `maps/world.esm.min.js` builds with source maps.
- b0a29f9: Removed the unused `mapbox` and `google-maps` entries from `libs.json`.
- 417bd2a: Removed `body.navbar` selectors that never match and duplicated declarations in `:root`, `.text-correct` and `.text-incorrect`.

## 1.7.4

### Patch Changes

- 7ecb816: Fixed `.card-table` bottom border on the last `tfoot` row and on row header `th` cells, and kept the rule above a `tfoot`.
- 4d92aae: Updated `$border-color-translucent-dark` to white at 8% so card, table and dropdown borders stay visible in dark mode.
- dd50698: Fixed Tabler Icons webfont `.ti` size in `.empty-icon` and its alignment in `.dropdown-item-icon`.
- 141b9f3: Fixed dropdown menus in an expanded `.navbar` overflowing the viewport edge by letting Popper position them.
- 9ccd968: Fixed hard-coded colors and shadows in `.ribbon`, `.loader`, `.stars`, `.card-cover`, forms and marketing with CSS variables.
- 93191c3: Fixed hard-coded `1px` borders, font weights, hero font sizes and transition times to use the shared tokens.

## 1.7.3

### Patch Changes

- 62faccc: Fixed `Autosize` moving the scroll position of a scrolled ancestor when the textarea is resized.
- 21dc7f5: Fixed `.card-table` losing its rounded corners inside `.table-responsive-sm` to `.table-responsive-xxl` wrappers.
- ec4b184: Fixed `.modal-header` vertical padding so multiline and wrapped `.modal-title` text no longer touches the header edges.
- 8dec6f4: Fixed Tom Select chip `border-radius`, optgroup dividers and dropdown corners that read undefined `--bs-*` variables.

## 1.7.2

### Patch Changes

- f251b2f: Fixed `Datepicker` throwing on a click when the start of a range is clicked again to clear it.
- 3dba8bc: Let `data-bs-dismiss="offcanvas"` close a responsive offcanvas (`.offcanvas-lg` etc.) without `data-bs-target`.
- 19fc71a: Fixed `.table-primary`, `.table-warning` and other table variants showing light backgrounds in dark mode.

## 1.7.1

### Patch Changes

- 50c15e7: Fixed `.breadcrumb` link styles applying to the items of a dropdown placed inside it.
- 2bdbab3: Fixed dark mode contrast of `.text-muted` and other `muted` theme color utilities with a lighter `--tblr-muted` value.
- 1745d1f: Fixed the `.flag` size classes, which were stretched to one height inside flex containers because the height came from `aspect-ratio`.
- db649f4: Fixed `.form-check-label` stretching the clickable area of a checkbox or radio across the whole row.
- f076113: Fixed the arrow position and the room kept for it in `.form-select-sm` and `.form-select-lg`.
- 0d2e253: Fixed `.modal-lg` and `.modal-xl` falling back to the default width in viewports below the `lg` and `xl` breakpoints.
- 5d5186e: Fixed `Modal` and `Offcanvas` not returning focus to the element that opened them when closed.
- e069052: Fixed `.page-text` in pagination using the body font size instead of `--tblr-pagination-font-size`, including `pagination-sm` and `pagination-lg`.
- ac8eb82: Fixed ApexCharts demos and Dropzone previews to respect `prefers-reduced-motion`, with a shared `prefersReducedMotion()` helper.
- 8336b33: Added a focus ring to `.card-body-scrollable` and `.table-responsive` so a scrollable region that is focused with the keyboard is visible.
- cf3ceaa: Fixed the native clear button missing from `.form-control` search inputs in Chrome and Safari.
- 73392da: Fixed `.sortable-drag` tilting the dragged element itself in native drag mode, which broke the drag.
- c9e9b9b: Fixed the uneven `.table-bordered` grid in the dark theme by using the opaque border color.
- f1a49aa: Fixed `.text-bg-*` and `.progress-bar` hard-coding white text instead of reading the `--tblr-*-fg` tokens.
- 3eaeb74: Fixed the Tom Select focus ring leaving the wrapper border visible at the corners.
- 0df5946: Fixed the Tom Select focus ring flashing black before it fades in.
- 7ee278f: Fixed the square start corners of a Tom Select that opens an `.input-group`.
- 01f6a6c: Fixed the Tom Select dropdown text growing to the mobile font size on phones.
- fa4c175: Fixed the bright dividers before the remove button of Tom Select chips in the dark theme.

## 1.7.0

### Minor Changes

- ace9a4f: Added `.datagrid-horizontal` and `.datagrid-cols-{n}` classes and more datagrid examples and docs.
- 964eb7c: Added `dateFormat` patterns such as `iso` or `DD.MM.YYYY` and a `boundInput` option for ISO form values to `Datepicker`.
- 725e45d: Added the `weekNumbers` option to `Datepicker` to show the week number in front of each row.
- 0647af1: Added the `--tblr-fill-*` tokens and `.bg-fill-*` utilities, used by badges, avatars, code, progress and range tracks and the hover background.
- 8f00eab: Added `--tblr-form-check-*` and `--tblr-form-switch-*` variables, with shared `--tblr-control-checked-bg` and disabled tokens on `:root`.
- 8f00eab: Added `--tblr-control-*` variables to `.form-control` and `.form-select`; sizes and the file button now follow them.
- 8f00eab: Updated icon addons, select groups, `.col-form-label`, validation icons, OTP and Tom Select to read the `--tblr-control-*` and `--tblr-btn-input-*` variables.
- 8f00eab: Updated `.form-select-sm`, `.form-select-lg` and small Tom Select to match `.form-control-*`, so small controls are now 32px tall.
- bb60211: Updated `.form-switch` with a filled gray off track, a white knob with an even gap and a new `$form-switch-bg` variable.
- f7c848a: Added the Hover gallery component with `.hover-gallery`, `.hover-gallery-item` and `.hover-gallery-indicators` classes.
- c493436: Added the `.list-icon` component for lists with icon markers, with `.list-icon-inline` for entries in a row.
- 681b6eb: Added the image label component: `.img-labeled` and `.img-label` pin a short text or an icon to a corner of an image.
- 68da446: Updated the flags plugin to Tabler Flags: 304 flags at a 5:4 ratio, 50 new like `.flag-country-nato`, old codes kept as aliases.
- 8f00eab: Added `--tblr-input-group-addon-*`, `--tblr-form-floating-*` and `--tblr-range-*` variables to input groups, floating labels and range inputs.
- 03e2775: Updated `<kbd>` to a compact key cap and added `.kbd-group` and `--tblr-kbd-*` variables for keyboard shortcuts.
- 69c1114: Added item slots, `.list-group-sm` and `.list-group-lg` sizes, selectable and nested items to the list group.
- a845ab0: Added `.map-marker` with dot, pin, pulse and color variants, `.map-popup-card`, `.map-tooltip` and MapLibre styles in `tabler-vendors.css`.
- a845ab0: Added the `MapView` component in `tabler-map.js` on MapLibre GL JS 6: `data-bs-toggle="map"` makes a themed map with markers, popups, routes and a globe.
- d6cfffb: Added the `.mockup-browser` component that frames a screenshot or any content in a browser window with an address bar.
- 6c46d55: Added `NavOverflow` component that moves nav items that do not fit into a More dropdown, with a `.nav-overflow` wrapper.
- 86388e4: Added `combined` as a `data-bs-navbar-position` value to show both navbars at once.
- 3f3aae9: Added the `NumberInput` component, a `.number-input` quantity input with buttons, bounds, hold-to-repeat and keyboard support.
- 12c045f: Updated `.pricing` to ship in the core `tabler.css` bundle instead of `tabler-marketing.css`.
- 28c24bf: Updated `.shape` to ship in the core `tabler.css` bundle instead of `tabler-marketing.css`.
- 744f9fe: Added the `.text-shimmer` class that sweeps a highlight across a label, with an optional `.text-shimmer-loader` spinner.
- 5cbc443: Added a `mist` gray palette for `data-bs-theme-base` and removed the hidden `pink` base from `tabler-themes.css`.
- 00746f2: Added `.input-icon` support for Tom Select: a leading icon no longer overlaps the selected value.
- 8ab6441: Added the `VectorMap` plugin: an SVG world map with values, color scales, a legend, markers, lines, selection, tooltips and zoom.

### Patch Changes

- d75c5d6: Updated `--tblr-bg-surface-tertiary` to a translucent color, so card headers, footers and table stripes show on dark cards.
- 9368b8e: Fixed the default `.btn` turning see-through on hover and active by mixing the tint over `--tblr-bg-surface`.
- b168be1: Updated filled `.btn-*` variants with a subtle border, inner edges and a faint gradient; outline buttons lose their shadow.
- b168be1: Updated `.btn-xl` with a `1.25rem` font, `1.75rem` icons and a larger radius; `.btn-sm` gets `0.75rem` side padding.
- e3739a1: Fixed `.card-table` rounding the outer cells of every row: only the cells in the card corners are rounded now.
- 6394af0: Added ESLint with `typescript-eslint` and fixed its findings in `Datepicker`, `Dropdown`, `Tooltip` and `Sparkline`.
- 3275bff: Fixed `$border-color-translucent-dark` overbrightening card, alert, dropdown and table borders in dark mode.
- d75c5d6: Fixed dark mode contrast of nav links, list group headers, toast headers, breadcrumbs, the footer, `.form-control-light` and `.form-help`.
- a1b46ae: Fixed `Datepicker` getting stuck closed after the calendar plugin throws in `show()` or `hide()`.
- d75c5d6: Fixed `.input-group-text` contrast in dark mode with the `--tblr-secondary-color` text color and a translucent background.
- dcacb65: Fixed `.table-striped` rows and `thead th` backgrounds that were invisible in dark mode on cards.
- 462835f: Fixed the square corners of disabled Tom Select fields and the square focus ring of small and large ones.
- 9d837ea: Fixed `.input-icon` icons off-center in small and large inputs and selects: the addon follows the control size.
- 252c914: Updated the `tabler.js` build target from ES2015 to ES2022, making `tabler.min.js` about 1.5 kB smaller (gzip).
- 9fb6930: Fixed the vertical navbar submenu painting over the `.navbar-footer` user dropdown.
- 252c914: Removed Sass doc comments from `tabler.css` and `tabler.rtl.css` by switching them to `//` comments.
- 530f11b: Fixed `.nav-segmented` icons staying gray on hover: they follow the link color like the text.
- 2726bc4: Updated the `tabler.min.js` minification to two terser compress passes.
- fbf2bdb: Updated bundled `dropzone` to v6.3.5, `driver.js` to v1.10.1, `fslightbox` to v3.8.0, `fullcalendar` to v6.1.22, `hugerte` to v1.0.14 and `plyr` to v3.8.5.

## 1.6.1

### Patch Changes

- e3da90e: Fixed Autosize adding a phantom line after shrinking past `max-height` and wrong heights on `content-box` textareas.
- e3da90e: Fixed Clipboard reading `data-bs-text` as a number or JSON, copying hidden text, and added `reset()` for a `delay` of 0.
- 7748029: Fixed CountUp firing `complete.bs.countup` twice when `update()` ran before it scrolled into view.
- 0a9edcb: Fixed CountUp printing `-0` when a value crosses or rounds to zero.
- e3da90e: Fixed CountUp `reset()` blocking a later viewport start and `data-countup` or `data-sortable` JSON that is not an object.
- e3da90e: Fixed Datepicker `dispose()` swapping the input for a stale clone, a hide timer after dispose and `Date` values for `dateMin`.
- 6199b80: Fixed published types requiring the optional `vanilla-calendar-pro` peer dependency to be installed.
- 4f471dd: Fixed `Datepicker` failing with `data-bs-display-months-count` on Vanilla Calendar Pro 3.4 by registering its extensions.
- e3da90e: Fixed Datepicker keeping a deselected date in the field, `setSelectedDates()` not writing it and not opening on the value's month.
- 0f6e843: Fixed tab, tooltip, popover, dropdown and toast init running before `DOMContentLoaded`, dropping early listeners.
- e3da90e: Fixed an open dropdown with a disabled toggle being closed by outside clicks, matching Bootstrap.
- c89bf8d: Fixed autosize not resizing a `position: fixed` textarea.
- 70b8372: Fixed `.card-progress` to keep a 2px bar fallback when it isn't a direct child of `.card`.
- ee3843e: Fixed `Confetti` firing `end` after `dispose()`, stalling without a 2D context and sizing its canvas with the scrollbar width.
- d104e78: Fixed Confetti ignoring the trigger's `data-bs-*` options when `data-bs-target` points elsewhere.
- 29818fc: Fixed `Manipulator.setDataAttribute()` writing `data-tblr-*` attributes instead of `data-bs-*`.
- 9fc77b9: Fixed `Datepicker` popup snapping back to the input on resize and an initial `value` not being formatted.
- e2da442: Fixed the OTP input ignoring `groups` for its length when neither `length` nor `maxlength` is set.
- 01857d2: Fixed `Sparkline` wiping author content when empty or disposed, keeping stale tween attributes and skipping single-value lines.
- e3da90e: Fixed InputMask dropping options other than `mask` and `lazy`, rejecting non-string masks and a bare `data-mask-visible`.
- e3da90e: Fixed Bootstrap components rejecting a jQuery collection passed as the element, `container`, `parent` or `target`.
- e3da90e: Fixed tooltip, popover, dropdown, toast and tab auto-init stopping the bundle on one bad element and ignoring `data-tblr-toggle`.
- e3da90e: Fixed OTP input firing `complete` on every edit of a full value, events on no-op keys, invalid `length` and `type="email"` fields.
- 3d10e24: Fixed the Delete key in `.otp` jumping to the last slot; it now removes the character under the caret and keeps it in place.
- dee65f2: Fixed `OtpInput` reusing a stale tap position, overwriting only one slot of a selection and breaking IME composition.
- 4b02b6a: Fixed `new Tooltip()`, `new Popover()` and `new Dropdown()` on auto-initialised elements ignoring options and doubling listeners.
- e3da90e: Fixed Clipboard `target`, Strength `input` and Datepicker `positionElement` selectors failing on ids like `#user:1`.
- e3da90e: Fixed sidebar toggles not syncing when `tabler.js` loads after `DOMContentLoaded` and errors on synthetic clicks.
- e3da90e: Fixed a partial `messages` or `weights` config on the Strength meter dropping the default entries.
- f7c3956: Fixed the strength meter rating a confirm-password field after it instead of the password field before it.
- e3da90e: Fixed SwitchIcon throwing and staying in the loading state when a `wait()` promise settles after `dispose()`.
- e3da90e: Fixed the theme switcher and sidebar toggle failing when `localStorage` is blocked, and ignored unsafe `?theme=` URL values.
- e3da90e: Fixed `data-bs-delay` on tooltips and popovers being overridden by the default delay.

## 1.6.0

### Minor Changes

- a13ebc3: Added `Autosize` component to `tabler.js`, with `update()` and `dispose()` methods.
- 038000f: Added the `--tblr-btn-input-*` control scale on `:root` (padding, font size, line height, radius, min height per size).
- 0e2faa0: Added a `Clipboard` copy button built on the browser API; `dist/libs/clipboard` is deprecated.
- e63fe34: Added a `Confetti` component with `data-bs-toggle="confetti"`, a demo page and docs.
- 118380d: Added `Datepicker` plugin built on Vanilla Calendar Pro with a `datepicker` preview page; Litepicker is deprecated.
- 0905918: Updated the default gray scale (`$gray-50`…`$gray-950`) to `neutral`; `data-bs-theme-base="gray"` keeps the 1.5 look.
- 2b44251: Added the `.flag-country-yt` flag for Mayotte.
- 744a09c: Updated the focus indicator from a `box-shadow` to an `outline`; the `$*-focus-box-shadow` variables and tokens are deprecated.
- c1373d7: Added `--tblr-hover-bg` variable and used it for the hover background of buttons, nav links, dropdown items and list groups.
- be30919: Updated `.legend` into a legend item with `.legend-dot`, `.legend-value`, `.legend-off` and `.legend-list`, plus a `Legend` component.
- a984752: Added `.legend-lg`, `.legend-unit` and `.legend-list-divided` for large legend items with a big value and a unit.
- c1786b5: Added `dialog::backdrop` styling so a native `<dialog>` uses the same backdrop as modals.
- 7e7b2ce: Added `.navbar-floating` and the `data-bs-navbar-style="floating"` theme setting for a navbar and sidebar with a `0.5rem` gap.
- 7e7b2ce: Added `.offcanvas-floating` and the `data-bs-offcanvas-style="floating"` theme setting for an offcanvas with a `0.5rem` gap.
- 0fe02b3: Updated color mixing to `color-mix(in oklab)`; the `--tblr-*-rgb` variables are deprecated and stay until 2.0.
- a744b84: Added the `OtpInput` component with grouped slots, masking, and validation states.
- a984752: Added `.page-section-title` and `.page-section-description` classes for section headings inside the page body.
- 107e493: Updated the palette to `oklch()` and masked the check, switch, toggler and carousel icons; `tabler` JS namespace is deprecated.
- a9efcc2: Added the Signal component (`.signal`): stepped bars that show a level such as priority, with a `Signal.astro` wrapper.
- bd60d5f: Added SortableJS drag styles; set `forceFallback` to `true` on a `data-sortable` list to drag a styled, tilted copy.
- 5d5be36: Added `Sparkline` component: inline SVG line, bar and circle charts from `data-bs-values`, with size classes and signed bars.
- 9669c0a: Added a `Strength` password meter with a segmented bar, configurable scoring and `change.bs.strength`.
- 0776b88: Added a `switch-icon-loading` state and a cancelable `toggle.bs.switch-icon` event with `event.wait(promise)` for async toggles.
- bd5c010: Added `SwitchIcon`, `CountUp`, `InputMask` and `Sortable` components to `tabler.js`.

### Patch Changes

- da79879: Updated `.accordion-button` line height to `1.25rem` via the `--tblr-accordion-btn-line-height` variable.
- b295d84: Fixed `.accordion-button-toggle-plus` with sprite icons by rotating the plus into a close icon instead of hiding a path.
- 72a95d8: Fixed `.alert` layout so headings, descriptions, lists and buttons align and stack correctly.
- 62408b8: Added a dependency-free `Autosize` component that fires `resized.bs.autosize`; `dist/libs/autosize` is deprecated.
- 3b8bf55: Updated the button, list group, `bg-pattern-*` and color utility styles to cut 72 kB from `tabler.min.css`.
- 58e03a9: Fixed `CountUp` rejecting numbers and booleans written as strings in `data-countup`, which countUp.js accepted.
- ea10f0e: Added a dependency-free `CountUp` component that respects `prefers-reduced-motion`; `dist/libs/countup.js` is deprecated.
- 58e03a9: Updated `theme-color-lighter()`, `url-svg()`, `varify()` and five more Sass helpers to deprecated; they warn when used.
- 18a8a49: Fixed `.dropdown-menu-arrow` border rendering on Firefox by trimming the clipped edges.
- 58e03a9: Added `$enable-deprecated`; set it to `false` to leave the deprecated aliases and `--tblr-*-rgb` variables out of the CSS.
- f778fcf: Removed the `js/tests` and `scss/tests` folders from the published `@tabler/core` package.
- 7bfeb12: Fixed `.alert-link` changing color on hover.
- cac3179: Fixed the ApexCharts tooltip arrow staying white in Safari by painting `.apexcharts-tooltip-arrow` directly.
- 7bfeb12: Fixed `.card-options` being taken out of the `.card-header` flow by `position: absolute`.
- 79796ab: Fixed `.card-progress` to overlay the card like `.card-status`, so its rounded corners match the card's radius exactly.
- db903c3: Fixed `.card-status-*` strip corners not matching the card's `border-radius`.
- 7bfeb12: Fixed `Datepicker` reopening on a second trigger click, its `show` and `hide` events, and its color scheme on light pages.
- 7bfeb12: Fixed `--tblr-focus-ring-width` and `--tblr-focus-ring-color` overrides having no effect when set on a component.
- ce52364: Fixed the default browser border and padding on `.form-help` when it is a `<button>`.
- 7bfeb12: Fixed the `.form-switch` knob not moving in RTL and its size in `.form-switch-lg`.
- 7bfeb12: Fixed `tabler.js` stopping on page load when one element has an invalid `data-*` config; the error is logged instead.
- 67a3795: Fixed `.input-group-flat` so `.input-group-text` follows the `.is-valid` and `.is-invalid` border and focus colors.
- 531529a: Fixed jQuery `.on()` listeners not receiving Bootstrap events like `show.bs.dropdown` in all components.
- 127c56b: Fixed the empty gutter to the right of the navbar on non-scrolling pages by dropping `scrollbar-gutter: stable` from `html`.
- 7e7b2ce: Fixed the menu row of the two-row navbar staying light with `data-bs-navbar-theme` set to `dark` or `primary`.
- 7bfeb12: Fixed missing `IMaskInstance` and `SortableInstance` in `dist/types`; `vanilla-calendar-pro` is an optional peer dependency.
- 64dd529: Fixed the `.form-selectgroup-label` icon-only margin applying to icons nested deeper inside the label.
- 9268348: Fixed `.stretched-link` on a `.btn` so the link covers its whole container instead of only the button.
- 61b492e: Fixed `.table-striped` and `.table-striped-columns` repainting rows and cells that set a `.bg-*`, `.table-*` or inline background.
- fa70c03: Fixed missing border between `.card-table` and `.card-footer` when wrapped in `.table-responsive`.
- a9efcc2: Fixed Tom Select growing taller on focus when the selected item has an indicator (avatar, flag, badge).
- c99a436: Fixed `.is-valid` and `.is-invalid` border colors and focus ring on Tom Select `.form-select` fields.
- 57e213b: Updated `.form-hint` to Bootstrap's `.form-text`, with `.form-hint` kept as a deprecated alias.
- cc7afaf: Fixed a disabled off `.form-switch` looking the same as an enabled one by filling its track and darkening the knob.
- 03985e3: Fixed text badges in navbar `.nav-link` overlapping the title and causing horizontal scroll in the stacked menu.
- 0460291: Updated the `.navbar-vertical` styles to be generated once instead of per breakpoint, cutting 36 kB from `tabler.min.css`.
- 2b44251: Updated the flag, payment and social SVGs in `dist/img` to be minified with svgo, and copied only the images the CSS uses.
- 41e2dc7: Updated `pre` font size to 13px with a new `$pre-font-size` variable, and `$markdown-pre-font-size` for `.markdown`.
- 2b99ed5: Fixed invisible text selection inside `pre` blocks in light mode.
- c1786b5: Added `overscroll-behavior: contain` to `.modal`, `.modal-body`, `.offcanvas-body` and `.dropdown-menu-scrollable`.
- 3e60b18: Fixed `.navbar-expand`, `.btn-link:hover`, `--*-darken`, `.ribbon` fold colors, `.avatar-brand` z-index and dark mode literals.
- 1ffbeec: Updated the Bootstrap component port to strict TypeScript with typed `ComponentConfig` types and added `eventActionOnPlugin`.
- 3e60b18: Fixed light theme islands losing `data-bs-theme-primary` and radius, and added `.theme-dark` to the dark mode selectors.
- 8db40cd: Fixed Tom Select controls being shorter than `.form-control` by using Tabler input metrics in all sizes.

## 1.5.1

### Patch Changes

- f311287: Fixed `.card-code` so the code block follows the card corners instead of drawing its own `border-radius`.
- 718fdd7: Fixed invisible box-shadows in dark mode with a new global `--tblr-shadow-color` `light-dark()` token.
- 6f64f33: Fixed the `.dropdown-menu-arrow` border color and replaced the deprecated `clip` with `clip-path`.
- b8e61db: Fixed the folded sidebar flashing the active submenu as a flyout on reload before `tabler.js` closed it.
- 692a3a2: Fixed the invisible `.form-switch` knob in light mode by restoring a gray `$form-switch-color`.
- d4c5be6: Fixed unreadable counter digit on not-yet-reached steps by giving `.step-item` `::before` the `--tblr-disabled-color`.

## 1.5.0

### Minor Changes

- 9ea657b: Added `.text-gray-50` through `.text-gray-950` utility classes alongside the existing `.bg-gray-*` utilities.
- 100a37b: Added background pattern utilities and documentation, including updated preview demos.
- 9d5c83f: Added Bootstrap 5.3.8 to the core source tree, with SCSS as modules and components converted to TypeScript.
- e1ecd39: Updated the supported browser baseline to what the CSS needs: Chrome 123, Firefox 128, Safari 17.5.
- 9c5d729: Added `.btn-ghost` button variant with transparent background and hover effects.
- ec94693: Added `.card-gradient` component with gradient variants, direction modifiers, and animated backgrounds.
- 324b0fb: Added `--tblr-card-header-bg` and `--tblr-card-footer-bg` variables so both backgrounds can be overridden independently.
- 09d419a: Added a `--tblr-chart-1` … `--tblr-chart-5` palette and wired ApexCharts theme tokens, so every chart follows the color mode.
- d2c1271: Added TypeScript declarations to the npm package, so `import { Modal } from "@tabler/core"` is typed.
- 9d5c83f: Added support for `data-tblr-*` attributes alongside `data-bs-*` for dropdown and other components.
- bf9e7ad: Added Driver.js to `libs.json` and `dist/libs` for product tours.
- bf9e7ad: Added `--tblr-dropdown-item-gap`, `--tblr-dropdown-item-icon-size` and `--tblr-dropdown-item-icon-color` to `.dropdown-menu`.
- 4f6e99b: Added a folded sidebar (`navbar-folded`, `navbar-folded-hover`) with flyout submenus, a pin toggle and a light `16rem` sidebar by default.
- 70f996b: Added the `.font-sans-serif`, `.font-serif` and `.font-comic` utilities next to `.font-monospace`.
- d2c1271: Added `.bg-gradient-{from,via,to}-transparent` and `-inverted` gradient stops, which the gradient docs already described.
- 5baf073: Added 74 new payment provider icons imported from `tabler-payments` and removed 12 outdated providers like `dotpay` and `solo`.
- 5e119d4: Added `bg-blur` utility and increased `container-tight` width for layout flexibility.
- 70f996b: Added the `data-bs-layout`, `data-bs-navbar-position`, `data-bs-navbar` and `data-bs-navbar-theme` layout settings.
- 0c79963: Added `media-print` mixin and print styles to hide interactive components during printing.
- 48dbd1e: Updated the core build system from Rollup to Vite, with identical UMD and ESM output.
- 4ce08ca: Updated the navbar-side component and reorganized its apps, language, notifications and user sections.
- 70f996b: Added `.navbar-side` support in the vertical navbar: a wrapper for a trailing `.navbar-nav` group pinned to the bottom of the menu.
- f11ece4: Added `--tblr-pattern-opacity-factor` and `.bg-pattern-opacity-*` utilities for background patterns.
- cad8eb8: Removed the `$prefix` Sass variable; the `--tblr-` prefix is now applied at build time by PostCSS.
- 9c5d729: Added Progress Background component with text labels and value display.
- 9c5d729: Added `.progress-lg` and `.progress-xl` size variants for the progress component.
- 9c5d729: Added Progress Steps component for step-by-step navigation indicators.
- bea97f8: Removed `@hotwired/turbo` integration, including `.turbo-progress-bar` styles and the Turbo loader preview demo.
- 8962710: Removed unused SCSS `!default` variables, which now raise a Sass error when set via `@use ... with (...)`.
- 9820d11: Updated core SCSS to the Sass module system with `@use` and `@forward`.
- 4f6e99b: Added `nav-section-title` group labels to the vertical sidebar, shown as short separators in the folded state.
- 4f6e99b: Added a `navbar-footer` sidebar zone with a user block; the sidebar nav scrolls between the pinned brand and footer.
- ff24af9: Updated the default `$font-family-sans-serif` and `$font-family-monospace` to the system font stacks. Tabler no longer bundles a web font, so no font files are downloaded.
- 9dd26fd: Changed the default theme of `tabler-theme.js` to `auto`, following the system color scheme.
- 7556ae2: Added an `auto` color mode to theme settings with system `prefers-color-scheme` support.
- e3d86c5: Updated `apexcharts` from `3.54.1` to `7.0.0` and added `--chart-{id}-color-{index}` variables.

### Patch Changes

- 1effe22: Fixed invisible keyboard focus indicators and added `prefers-reduced-motion` and `forced-colors` support.
- 09d419a: Documented the ApexCharts dual license, which applies to the copy shipped in `dist/libs`, in the readme and chart docs.
- 080d3aa: Fixed the ApexCharts tooltip arrow staying white on the dark tooltip by setting the `--apx-tt-bg` and `--apx-tt-border` tokens.
- ffe3489: Updated `.badges-list` to `.badge-list` and `.tags-list` to `.tag-list`, keeping the old names as deprecated aliases.
- 059bae1: Updated Bootstrap exports to a single source of truth in `bootstrap.js` and removed the duplicates from `tabler.js`.
- 4f6e99b: Moved `btn-floating` to the end side of the screen, so it does not cover the sidebar.
- 5018aa9: Fixed `.btn-icon` to be square by aligning `min-width` calculation with base `.btn` formula.
- a508bb6: Updated hardcoded `rem` and `px` values to SCSS variables across core components for easier theming.
- c71a321: Updated the `@tabler/core` README with package usage, optional stylesheets, Sass setup and browser support.
- a0d84f6: Updated the npm package README with badges, quick links, CDN usage, documentation and changelog links.
- c860288: Fixed icon alignment for `.btn-sm` and `.btn-xl` sizes.
- 1adb710: Fixed `.alert-action` and `.alert-link` colors inside `.alert-important` so links stay readable.
- 2dc7eda: Updated `$border-color-translucent-dark` to `rgba(128, 150, 172, 0.2)` for better dark mode visibility.
- 09ab0bc: Fixed disabled buttons falling back to `currentColor` for the border and to a transparent background.
- febfa9f: Fixed the missing focus ring on buttons and `btn-check` button groups by using the shared focus ring token.
- 8324701: Fixed `.card-header` background being overridden by a `background: transparent` shorthand.
- 0187b26: Fixed the `card-status-*` strips leaving a thin line over the card border and a mismatched corner radius.
- 70ec683: Fixed card corner radius in tab layouts when tabs sit above or below tab content.
- c1e1fdf: Fixed the corner radius and the double bottom border on the first and last rows of a table inside a `.card`.
- de44d61: Fixed `.card-tabs .nav-tabs` sharing `z-index` with `.dropdown-menu`, which hid dropdowns behind card tabs.
- 6414238: Fixed barely visible checkbox and radio borders in dark theme by using `$input-border-color`.
- b1d49e9: Fixed CountUp to parse formatted number targets and avoid double-start when `enableScrollSpy` is enabled.
- 09d419a: Fixed chart colors in dark mode: axis lines and ticks, marker and treemap outlines, and the tooltip title.
- 070248d: Fixed dark mode link contrast: `--tblr-link-color` is now a lighter tint of `--tblr-primary` on dark surfaces.
- 601e950: Fixed dark mode text selection contrast with a new `$selection-bg` Sass variable.
- d0a793c: Fixed the disabled form control background in dark theme with a new `--tblr-bg-forms-disabled` variable.
- b1d49e9: Fixed dropdown `data-bs-boundary="viewport"` to use `document.documentElement` instead of the first `.btn` element.
- c527135: Fixed `.input-icon` inline-start padding for `.form-select`.
- 70f069c: Fixed `.form-select` keeping its default box-shadow inside `.input-group`.
- 9c78cf6: Fixed `.bg-gradient` conflicts that broke `from`/`via`/`to` rendering and updated the gradient docs.
- bc24b3a: Fixed `--tblr-gray-*-fg` tokens to map directly to `--tblr-gray-*` instead of contrast-based fallbacks.
- c8b8b24: Fixed gray theme custom properties output using SCSS interpolation and updated default `$body-color` to `$gray-500`.
- 70193fe: Fixed `.icon-pulse`, `.icon-tada` and `.icon-rotate` not animating webfont icons.
- f0b909d: Fixed the `sm` and `lg` size mismatch between form controls, buttons and input groups.
- 6e656ad: Fixed `.input-icon-addon` z-index issue with form validation feedback and added default height.
- b1d49e9: Fixed input mask `lazy` option to read `data-mask-visible` via `dataset.maskVisible`.
- fc16b6a: Defined `--tblr-body-text-align`, `--tblr-nav-link-font-size` and `--tblr-nav-link-active-color`, which the css already read.
- a883531: Fixed `.list-group-item-{color}`: the palette colors had no styling at all and no variant had its background.
- 9dd26fd: Fixed the markdown table header keeping its surface background instead of going transparent.
- 9d04e14: Fixed the marketing hero, browser and shape components reading custom properties nothing defined.
- 9dd26fd: Fixed `offcanvas-narrow`, which had no effect on the width of the panel.
- f5f75d4: Fixed print styles: hidden navbar/sidebar, forced light `color-scheme`, and avoided breaking `.card`/table rows.
- 1da70a7: Fixed ScrollSpy throwing on target ids that start with a digit, such as headings like `1. Setup`.
- 464a522: Fixed oversized and mismatched validation icons on `.form-select` and Tom Select selects.
- 8bc6fa7: Fixed status color classes to use CSS variables and to include the social colors.
- c527135: Fixed `.steps` horizontal overflow on small screens by enabling scrollable overflow below the `sm` breakpoint.
- cd0b210: Fixed the typographic `.steps` rule leaking its guideline and spacing onto the `.steps` component.
- 90c42f2: Fixed Tom Select's `.ts-dropdown` losing its z-index, background, and colors to the bootstrap5 preset CSS.
- 6849337: Fixed Tom Select styles to use `--tblr-*` variables instead of undefined `--bs-*` references.
- e206d7a: Fixed white space next to the scrollbar by using `scrollbar-gutter: stable` on `html`.
- bf9e7ad: Updated `.flag` to size by width with `$border-radius-xs` on `xs`, and narrowed tooltip `padding-x` to `spacer-2`.
- b8b63d7: Fixed Sass mixed-declaration warnings in the navbar, card, nav and table styles.
- 9432835: Updated SCSS files to use the `border-radius` mixin.
- 9c5d729: Updated `stroke-width` for `.icon-sm` from `1` to `1.5` for better visibility.
- bf9e7ad: Updated `.input-group-flat` addons to drop the inner border and sit above the control.
- fa678a7: Updated root color tokens to use CSS `light-dark()` so paired values live in one `:root` declaration.
- 7ae422f: Updated core SCSS to logical properties and a `--tblr-dir` multiplier, so RTL works with plain `tabler.css`.
- 301e778: Updated `rgba()` calls to the modern `color-mix()` and `color-transparent()` functions.
- 9dd26fd: Fixed the avatar corner radius inside `.form-imagecheck-image` and set `.nav` font size to the body font size.
- 4f6e99b: Fixed the `navbar-toggler` icon: the middle bar was flex-squeezed, breaking the open-state X and shortening the hamburger.
- 9c5d729: Added smooth transitions for progress bar `width` and `background-color` changes.
- 1489b13: Added `.prose` alias for markdown content and updated preview/docs references and redirects.
- f35aab3: Added the same border and radius to `figure` images as plain images in `.prose` and `.markdown` content.
- 66dc336: Fixed the `caret()` mixin by restoring `$caret-width` to `0.36em`.
- 70f996b: Fixed the sidebar marking two items as selected: a group holding the current page is now emphasized, not filled.
- 70f996b: Fixed the vertical navbar brand sitting at the far edge on small screens when nothing follows it in the top bar.
- 9c5d729: Updated skip-link to use `visually-hidden` for improved accessibility.
- 346e091: Fixed oversized `dist/libs` by copying only the runtime files each library declares in `libs.json`.
- d2c1271: Fixed `tabler-theme.js` replacing a server-rendered `data-bs-theme` when the visitor has no stored choice.
- 736e604: Updated deprecated global Sass functions to module equivalents (`map.merge`, `string.slice`, `math.percentage`, etc.).
- b8b63d7: Updated Bootstrap to v5.3.8.
- 9c5d729: Updated trending component to use `arrow-up`/`arrow-down` instead of `trending-up`/`trending-down`.
- 70ec683: Updated `$card-status-size` default from `$border-width-wide` to `3px`.
- 666ccd6: Updated shadow tokens (`--tblr-shadow-*`) to use the new `xs`–`2xl` and `overlay` values.

## 1.4.0

### Minor Changes

- 9951fe9: Enhance button and hover animations
- a200d30: Improve breadcrumb styles
- 49ab9ea: Add new Tabler Illustrations

### Patch Changes

- 6c4dd36: Update class names from `*-left`, `*-right` to `*-start`, `*-end`
- 6fec73a: Fix relative line heights in buttons
- db6200a: Remove `license_key` option from HugeRTE init object
- e96f055: Add different favicon to development environment
- 6c38a48: Update Bootstrap to v5.3.7
- 2a12f72: Update CSS calculations to use `calc()`
- 666a296: Fix list group item hoverable only with `.list-group-hoverable` class
- cfd4cb6: Fix `.pagination-link` hover styles to non-active items

## 1.3.2

### Patch Changes

- 446c34e: Fix README file in core package

## 1.3.1

### Patch Changes

- a7f73d7: Fix README file in core package

## 1.3.0

### Minor Changes

- a1af801: Add FullCalendar integration
- b9d434d: Add new charts to dashboard pages
- 79bd867: Add new form layout page

### Patch Changes

- cac5d92: Update illustrations to v1.7
- f94b153: Add SRI hashes to scripts and styles
- c127d65: Fix colour picker preview page not displaying correctly
- b6e9b18: Update icons to v3.31.0
- 8850f61: Enhance pagination component with new styles
- 9910dd0: Add "text features" menu item
- 638f36c: Refactor SCSS variable names for shadows
- 0d501e9: Correct `aria-label` of app menu link
- 3a02ef9: Fix some marketing site rows overflowing on mobile
- fd0fd47: Improve card footer layout and enhance entry display format in invoices
- 74e5d26: Fix color badge in navbar menu
- 72a1d67: Add clipboard functionality to Tabler documentation
- bb617b8: Fix colour swatches on small screens
- d73d78e: Add missing `tw` entry in `flags.json`
- 19a3d20: Delete missing demo RTL style
- b5e2f54: Enhance dropdown components for better accessibility
- a41c956: Remove unnecessary `!important` from body padding
- e675389: Fix missing border-radius to `.card-header-tabs`
- 9007e73: Fix FAQ accordion structure

## 1.2.0

### Minor Changes

- c59bc9d: Add gradient background utilities
- f9e4da2: Add new apps card with brand icons in navbar
- 92a3afe: Replaced TinyMCE with HugeRTE to address license violation
- 199f39a: Update Bootstrap to version 5.3.5
- 9bbcb99: Add theme settings wizard
- b17b488: Add steps light colors
- 215eaa4: Add Turbo library integration

### Patch Changes

- aea3b0a: Rollback accordion component structure
- 3fc7b84: Add space between page numbers in pagination
- 2f8a372: Add Bootstrap components to Tabler JS
- 9fceadd: Fix tooltip colors in vector maps
- 44250db: Update avatar size variable to support list size configuration
- be1f3d1: Fix broken shape in South Korea flag
- c20d076: Refactor `border-radius` in components to use CSS variables
- 042e50f: Update disabled color variables in navbars
- 473fa38: Apply border radius to `tom-select` on focus
- 8646192: Add avatars page with various demos of avatars
- 922bb03: Minor spelling and grammar improvements to emails docs
- 44250db: Update avatar size variable to support list size configuration
- ddcd3a7: Refactor SCSS for alerts and close button styles
- e3d68d6: Fix `autosize` and `input mask` plugins to use window scope
- 4846828: Fix scrollbar color mixin to use body color variable
- 6b6617a: Improve README
- 94bea00: Make scrollbar track transparent
- e14e492: Fix scrollbar jumps when content is higher than screen
- 6d6d1bd: Add responsive font size for form controls on mobile devices
- 6c566cf: Add new advanced table example

## 1.1.1

### Patch Changes

- f29c911: Fix Documentation structure

## 1.1.0

### Minor Changes

- d3ae77c: Enable `scrollSpy` in `countup` module
- bd3d959: Refactor SCSS files to replace divide function with calc
- cb278c7: Add Segmented Control component
- b47725d: Add new text features page with mentions: user, color and app.
- b4b4d1a: Add Scroll Spy page
- 9cd5327: Update border radius variables for consistency across components
- 4376968: Add Signature Pad feature and signatures page
- f95f250: Update color utility classes and replace background colors in pricing table
- eaa7f81: Refactored the project into a monorepo, removed Gulp, and introduced a new, more efficient build process.
- ea14462: Add documentation for segmented control component
- 1edaff4: Add new payment provider (Troy)
- edbaa1e: Add selectable table functionality with active background color
- 378fba8: Refactor badge styles, remove Bootstrap styles
- f3c409f: Refactor alert component styles and markup, remove Bootstrap styles
- c240b5a: Refactor accordion component styles and markup, remove Bootstrap styles

### Patch Changes

- 687267d: Fix overflow of `label` in a `floating-input`
- 06b1dec: Fix size of `apexcharts` tooltip marker
- afd0700: Fix apexcharts heatmap example in docs
- 78383ef: Fix negative margins in `.navbar-bordered` variant
- 11f4487: Use the full license agreement for illustrations in docs
- b28ce9f: Fix vertical alignment in single page and error layouts
- 24b944c: Fix `.avatar-upload` double borders
- ca4ba14: Fixes navbar styles with new hover effects and color variables

## 1.0.0

### Minor Changes

- c276a8b: Add new `Tag` component
- d380224: Add customizable Star Ratings component using `star-rating.js` library
- 47cd6c1: Add `flags.html` page with list of all flags
- be67ab6: Update CSS class from `text-muted` to `text-secondary` for better Bootstrap compatibility
- 080c746: Adding `alerts.html` page with example of alerts.
- b381273: Change primary color value to new Tabler branding
- 75619dd: Unify dark mode with latest Bootstrap API and improve dark mode elements
- cc82dbf: New Chat component
- 5a03643: Adjusting form element sizes for enhanced mobile devices compatibility
- be14607: Add new color picker component using `coloris.js` library
- d046570: Update Tabler Icons to version 2.23 with 18 new icons added
- 5488c50: New page with payment providers: `payment-providers.html`
- 5488c50: Add support for new payment providers: 2c2p, Adyen, Affirm, Alipay Plus, Allegro Pay, Amazon Pay, Apple Pay, Autopay, Binance USD, Bkash, Cash App, Chime, EasyPaisa, Ethereum, Google Pay, HubSpot, iDeal, Litecoin, Mercado Pago, MetaMask, MoneyGram, OpenSea, Payconiq, Payka, Payline, PayPo, Paysafe, Poli,
  Revolut Pay, Samsung Pay, Shop Pay, Solana, Spingo, Stax, Tether, True USD, Venmo, WeChat Pay, Wise, Zelle

### Patch Changes

- 293d0a4: Change Twitter to X brand
- fd0935a: Updated link to icons documentation
- 1cf27dc: Dependencies update
- 041f4e4: Order menu items alphabetically
- 20cad01: Automatically retrieve and display the changelog from the CHANGELOG.md file.
- 34f3efc: Initialize Visual Studio Code config
- 7ba7717: Make horizontal rule direction aware
- 063ef58: Update Tabler Illustrations to v1.5
- 5e2c975: Update Tabler Icons to v3.29.0
- 9d5f7ca: Remove unused dependencies from `package.json`
- be69fd6: Replace Jekyll with Eleventy
- 2f5fad6: Dependencies update
- dfd7c88: Update TinyMCE to v7.0
- 056df18: Fix text color in dark version of navbar
- 17327dc: Remove invalid `z-index` setting for dropdowns
- 4ff077a: Update Tabler Icons to version 2.21 with 18 new icons added
- 867c8dd: Update Tabler Emails to v2.0
- d8605f2: Init changelog script
- 89c6234: Adding Two-Step Verification Pages
- f6e885b: Replace `.page-center` with `.my-auto` in single page layouts
- 7aa216f: Add border-opacity variable for improved color utility
- 88eb413: Fix icon display issues in the Star Ratings component
- 78392b6: Fix `color` of disabled `dropdown-item` in Navbar component
- 4deb8f4: Bump pnpm/action-setup from 2 to 3
- 9015472: Add social icons plugin
- 7fe30a1: `Dockerfile` fix
- e53942f: Update Jekyll to version 4.3.4
- 72f868b: Update Tabler Icons to version 2.20 with 37 new icons added
- e0443c0: Add Tabler Illustrations
- 5cca710: Update illustrations and enhance SVG handling in HTML
- 3a4f10f: Fix ids of custom size star ratings
- 7896562: Unify size of avatar, flag and payment components
- 1587905: Update icons to v2.42.0
- d9e00b2: Update Bootstrap to v5.3.0
- bc1d1a3: Set `font-size` of an `i` element with `icon` class in a `button` element
- 0195f9b: Dependencies update
- a5bf5d3: Fix icons in `form-elements.html`
- 736410c: Update Tabler Icons to v3.28.1
- 3f516ea: Fix `rgba` color values in `_variables.scss`
- e91884e: Fix description of alerts with a description
- 90cc744: Fix colors of disabled `.ts-control`
- 1801e41: Center content on error and single page layouts
- 45c83ac: Resolve map page issues
- faee63c: Improve base font family loading
- 5e7e0dd: Introduce Docker Compose Config to build and run Ttabler locally
- c293a66: Fix `@charset` CSS declaration in bundle.
- cb4a681: Update `_navbar.scss` with disabled dropdown menu items color
- af41fb3: Update Tabler Icons to v3.17.0
- 6cbe888: Update `@tabler/icons` to v3.0
- 0e4bf5f: Refactor data structure by converting YAML files to JSON
- 82cf257: Increase `z-index` of `ts-dropdown` to prevent overlapping by buttons
- 4b4b4f6: Adding punctuation to `SECURITY.md`
- a0a2d52: Fix form controls bugs in dark mode
- f45b697: Fix padding in code blocks
- 4de166d: Unified Box Shadows with Bootstrap Compatibility
- 87bf2f5: Remove duplicated setting of color in `th` element
- 5dc45aa: Fix layout of search results for small and medium screens
- 4ae0358: Remove `text-decoration` on hovering `a` element with class having `icon` class
- e798eb6: Fix small typo in tables docs
- 1c1d0c9: Improve documentation for alerts
- 371ef84: Bump `pnpm/action-setup` from 3 to 4
- 8421fc2: Update dependencies
- 0625f5f: Update Tabler Icons to version 2.22 with 18 new icons added
- ba65fc3: Update devDependencies
- a43ded4: Add All Contributions package to project for easy contribution tracking
- 2f622c9: Set value of `$font-family-monospace` as default
- 2c7c448: Refactor Dockerfile and package.json
- 5ec7f05: Resolved light dropdown issue on dark theme
- b0b07b9: Enhance documentation
- 0f129b1: Update Tabler Icons to version 2.19 with 18 new icons added
- 507df7b: Fix cells with inline icons
- 0e5b44a: Fix `color` of disabled `nav-link` in `nav-bordered`
- 65c1300: Fix the `z-index` value of the `nav-tab` inside `card-tab` #1933
- 8552a46: Switch from `npm` to `pnpm` for faster package installation
- 4a9e40d: Increase contrast of active `dropdown-item` in vertical layout
- 17ebdf4: Update documentation for Tabler components
- 4c88481: Add variable to configure `avatar-list` spacing
- df46ee7: Do not display empty `fieldset` element
- 875cafa: Refactor SCSS variables to use `color.adjust` for improved color manipulation
- eb28546: Add Tabler Illustrations
- 650d84c: Update required Node.js version to 18 and add `.nvmrc` file
- fb659d4: Fix table default background color
- f77c712: Avoid SCSS color dependency on `:focus`
- 71c68ce: Update changelog configuration and release scripts
- 34d124d: Update Tabler Icons to v3.26.0
- 4cd9215: Updated Tabler Icons to v3.24.0
- 7bb947b: Update Tabler Icons to version 2.18 with 18 new icons added
- c75cf55: Update Node.js engine requirement to allow versions >=20
- 1c34e8e: Update Tabler Icons to v3.14.0
- 289dd3b: Add Prettier to project for consistent code formatting
- f83e36c: Upgrade Node.js from version 18 to version 20 for improved performance, security, and feature updates.
- b885852: Update Tabler Icons to version 2.25 with 48 new icons added
- 53a5117: Fix responsiveness issue in Settings menu
- 38504e5: Added 3 new payments from Nepal: Esewa, FonePay, Khalti and Imepay
- 35ee14d: Add new Filled section to Icons page
- d32f242: Update `bootstrap` to v5.3.1
- d82f94e: Update package dependencies to latest versions
- 54c5ad0: Fix link to webfont version of Tabler Icons
- 94b83d4: Add support for changeset tool for more efficient and organized code changes
- c51ff28: Fix colors in date range datepicker

## 1.0.0-beta24

- Enhanced documentation.
- Updated illustrations and improved SVG handling in HTML.
- Updated copyright year in LICENSE file to 2025.
- Added marketing pages plugin.

## 1.0.0-beta23

- Documentation improvements.
- Added countup functionality and updated documentation example.
- Do not display empty `<fieldset>`.
- Set font-size of webfont icon inside a button.
- Ordered menu items alphabetically.
- Marked value of `$font-family-monospace` as `!default`.
- Fixed unpkg links to static-files icons.
- Fixed description of alerts with a description.
- Fixed layout of search results for small and medium screens.
- Removed invalid z-index setting for dropdown.
- Fixed IDs of custom size star ratings.
- Removed text-decoration on hover for elements with child icons.
- Fixed link to webfont icons.
- Updated color reference links in UI component documentation.
- Fixed typo in browser support documentation summary.
- Enhanced Figma plugin documentation with detailed usage instructions.
- Added documentation for Tabler Illustrations and updated index with a link.
- Enhanced documentation for various UI and icon sections.
- Added new documentation files for icons and UI components; restructured existing files.
- Updated documentation structure and content for icons and UI components.
- Removed outdated `menu.json` and added `index.mdx` files for UI documentation structure.
- General docs update.
- Increased contrast of active dropdown-item in vertical layout.
- Removed duplicated color setting in table headers.
- Increased `z-index` of `ts-dropdown`.
- Added social icons plugin.
- Described variables for datagrid in docs.
- Fixed multiple documentation issues.
- Removed unused config from the code.
- Fixed links to Tabler Icons.
- Updated dark image.
- Updated screenshot.
- Fixed icon issues.
- Fixed URL in documentation.

## 1.0.0-beta22

- Fixed `@charset` CSS declaration in bundle.
- Fixed cells with inline icons.
- Fixed padding in code blocks.
- Fixed colors in date range datepicker.
- Fixed icon display issues in the Star Ratings component.
- Fixed `z-index` value of the `nav-tab` inside `card-tab`.
- Fixed wrong gray colors.
- Fixed incorrect CDN URL in `webfont.mdx`.
- Ensured border color works in dark mode.
- Replaced `.page-center` with `.my-auto` in single-page layouts.
- Updated Tabler Emails to v2.0.
- Updated Tabler Icons to v3.26.0.
- Updated docs structure.
- Updated `download.mdx`.
- Updated Node.js to version 20.
- Improved base font family.
- Made horizontal rule direction-aware.
- Added new payment providers.
- Read changelog from `CHANGELOG.md` file.
- Initialized VS Code configuration.

## 1.0.0-beta21

- Updated dependencies.
- Updated Tabler Icons to v3.14.0 and the import script.
- Fixed invisible scrollbar in dark mode when navigating the preview.
- Styled `btn-close` specifically for `.modal-header`.
- Added proper borders to the ribbon start class.
- Changed brand color.
- Included `docs` in the `npm` package.
- Added Tabler Illustrations.
- Fixed use of the secondary color in specific form elements.
- Introduced Docker Compose Config for local Tabler builds.
- Allowed usage of `tinymce` v7.x as a peer dependency.
- Updated TinyMCE to v7.0.
- Rebranded Twitter to X.
- Replaced undraw illustrations with Tabler Illustrations.
- Added punctuation to `SECURITY.md`.
- Updated `_navbar.scss` to correct disabled dropdown menu item colors.
- Removed unused packages.
- Fixed map pages.
- Resolved issues with toasts in dark mode.
- Fixed alert background prefix.
- Corrected a typo in CHANGELOG.md.
- Fixed radial chart issue.
- Added documentation on running the site locally in Site README.
- Updated colors in `colors.mdx`.
- Fixed dynamic SCSS prefix in mixins.
- Changed `<h1>` to `<div>` in `navbar-logo.html`.
- Resolved vertical centering on error pages.
- Fixed navbar menu issues.
- Added `background-clip: border-box` to `.dropdown-menu` class.
- Replaced `href="#"` with `href="javascript:void(0)"`.
- Fixed disabled CSS class for links.
- Addressed missing variables and minor color adjustments.
- Improved heights, scrolls, and layouts in Docs examples.
- Fixed flags display in preview.

## 1.0.0-beta20

- Update `bootstrap` to v5.3.1
- Add new `Chat` component
- Add new `Tag` component
- Add customizable Star Ratings component using `star-rating.js` library
- Add new color picker component using `coloris.js` library
- Add `alerts.html` page with example of alerts.
- Add `flags.html` page with list of all flags
- Add Two-Step Verification Pages
- Add variable to configure `avatar-list` spacing
- Unify dark mode with latest Bootstrap API and improve dark mode elements
- Unify Box Shadows with Bootstrap Compatibility
- Avoid SCSS color dependency on `:focus`
- Update CSS class from `text-muted` to `text-secondary` for better Bootstrap compatibility
- Fix text color in dark version of navbar
- Adjusting form element sizes for enhanced mobile devices compatibility
- Resolved light dropdown issue on dark theme
- Update Tabler Icons to version 2.32 with 48 new icons added
- Fix table default background color
- Fix responsiveness issue in Settings menu
- Update required Node.js version to 18 and add `.nvmrc` file
- Add support for changeset tool for more efficient and organized code changes
- `Dockerfile` fix
- Switch from `npm` to `pnpm` for faster package installation

## 1.0.0-beta19

- Add customizable Star Ratings component using `star-rating.js` library (#1571)
- Add new "Filled" section to Icons page (#1574)
- Fix form controls bugs in dark mode (#1573)
- Fix text color in dark version of navbar (#1569)
- Changelog update

## 1.0.0-beta18

- new page: Cookie banner
- Unify dark mode with latest Bootstrap API and improve dark mode elements (#1561)
- Update Tabler Icons to version 2.18 with 18 new icons added (#1560)
- Switch from `npm` to `pnpm` for faster package installation (#1559)
- Add Prettier to project for consistent code formatting (#1558)
- Update required Node.js version to 18 and add `.nvmrc` file (#1555)
- Add All Contributions package to project for easy contribution tracking (#1556)
- Add support for changeset tool for more efficient and organized code changes (#1553)
- Fix bug where `border-1`, `border-2`, etc don't work (#1526)
- Fix indeterminate input background color (#1536)
- Update Bootstrap to `5.3.0-alpha3` (#1543)
- `tom-select` dark mode styling fixes
- Advanced udage of `tom-select` (#1480)
- Fix Dropdown menu in rtl mode (#801)
- Fix `tom-select` dropdown will be shaded in table-responsive (#1409)
- Remove overflow scroll from body
- Fix avatars overlap transparently (#1464)
- Fix TinyMCE dropdown icon list transparent (#1426)
- Dark mode lite colors improvement
- Fix non full width selects (#1392)

## 1.0.0-beta17

- update `bootstrap` to v5.3.0
- update icons to v2.1.2
- add 72 new brands, browsers logos update
- new `Trial ended` page
- new `Page loader` page
- new `Profile` page
- headings fix
- dropdown background color fix
- fix rgba conversion bug
- fix autofill text color, not matching in dark mode
- update license
- header html5 tags
- add input with appended `<kbd>`
- `bootstrap` import fix
- font improvements
- change `$body-color` to CSS variable
- scrollbars improvements
- move `@tabler/icons` to `dev-dependencies`
- fix #1370: avatar stacked list is not stacked anymore

## 1.0.0-beta16

- new `Photogrid` page
- `Steps` component improvements
- fix #1348: Make job listing responsive for smaller devices
- fix #1357: buttons group not active
- fix #1352: fix deprecation warning
- fix #1180: number input with `form-control-sm` looks weird
- fix #1328: color input should show different color for inner check symbol on white ellipse
- fix #1355 - missing font sizes
- update icons to v1.111.0
- homepage navbar fix
- fix #1262 - `.bg-opacity-xx` class is not functioning properly

## 1.0.0-beta15

- new `badges` page
- `<kbd>` styling
- update icons to v1.109.0
- `tom-select` border fix
- exclude `playgrounds` from build
- update jekyll to v4.3.1
- fix: facebook color update
- navbar aria atributes fixes
- fix #808 - `navbar-menu` and `sidebar-menu` has the same `id`
- fix #1335 - missing color variables usage in `alert` and `btn-ghost-*`
- move border style to CSS variables
- add missing forms
- `btn-actions` fixes
- replace `$text-muted` to css variable

## 1.0.0-beta14

- fix active items in dark mode
- update Jekyll to newest version

## 1.0.0-beta13

- update Bootstrap to 5.2.1, update dependencies
- new `tracking` component
- new radio button version of `form-imagecheck`
- update icons to v1.105.0
- dark mode improvements
- corrects the spelling of New Zealand (#1318)
- remove `$border-color-dark`
- fix #1301 - code snippets in docs look bad in dark mode
- fix #1305 - different default link color for dark mode
- fix popover background in dark mode
- fix button default border color
- fix `form-imagecheck` bg in dark mode
- navbar logo fix
- move card ribbons config to variables
- navbar border fix
- dark mode active fix
- using globalThis instead of window (#1315)
- fix #1210 - lastmod not generated for pages in `sitemap.xml`
- fix card border in dark mode
- fix #895 - background color overwrites background image
- fix #1302 - wrong card header in dark mode
- fix #1303 - wrong color when hovering over `selectgroup` in dark mode
- fix #1308 - bad coloring in table in dark mode
- fix #1273 - datepicker background color broken
- fix `$prefix` hard coded `layout/_dark.scss`
- fix #1275 - remove last border-right on progress bar
- fix #1261 - broken offcanvas bg

## 1.0.0-beta12

- new "Job listing" page
- new "Sign in with cover" page
- new "Logs" page
- new `progressbg` component
- add a lot of CSS variables
- add Dockerfile with alpine base
- add icon pulse/tada/rotate animations
- use `:host` in selectors to support Web Components
- use dark table variant colors in dark mode (#1200)
- update Tabler Icons to v1.96
- change `space-y` component
- headings, shadows and borders unify
- toggle TinyMCE dark mode and skin based on the set Tabler theme
- fix `card-footer` background
- fix headers weight
- fix transparent hover background in pagination
- fix dark mode card text color
- fix `--#{$prefix}card-bg` is undefined
- fix global variable for `.card` and `.btn`
- fix code sample in the customize tabler docs
- fix form elements demo page radio buttons
- replace `gulp-minify` with `gulp-terser`

## 1.0.0-beta11

- new `Dropzone` component
- new `Lightbox` component
- new `TinyMCS` component
- new `Inline Player` component
- new `Pricing table` component
- new `Datagrid` component
- new optgroup form examples
- new settings page
- update Tabler Icons to v1.78
- added popover docs page
- fix: #1125 incorrect chart display in the mobile version
- update Bootstrap to 5.2.0

## 1.0.0-beta10

- new `datatable` component
- update Tabler Icons to v1.67
- fix: #1024 - fix Tom-select in dark mode
- new carousel indicators: dots, vertical, thumbs (#1101)
- replace !important modifier with more specific selectors (#1100)
- new `FAQ` page

## 1.0.0-beta9

- fix: #1061 - list group item colors in light and dark modes
- new `tasks` dashboard
- fix: #1059 - upload button in form element in dark view has problem
- fix: #1052 - card background icon is practically invisible
- remove Inter font and use default font system stack
- fix: #1018 - vector map not working
- fix: #1035 - wrong background color of hovered list group items in dark mode
- dependencies update
- add `font-display: swap;` to improve font loading
- new `Boxed` layout

## 1.0.0-beta8

- update dependencies
- new vector maps demos
- fixes update map on resize
- docs improvement
- replace `badge` with `status-dot` in `navbar-notifications.html`
- map tooltip fixes

## 1.0.0-beta7

- fix: #1019 - project-overview.html link not working
- fix: #1010 - card with bottom tabs has incorrect border radius
- uptime monitor mobile fixes
- navbar dark button fix
- `tabler-icons` link
- autoloading webfonts
- cards fixes, new cards demos
- ruby dependencies update
- RTL stylesheet fixes
- new card action demos

## 1.0.0-beta6

- pricing cards fix
- fix bug `fw-...`, `.fs-...` is missed (#987)
- avatar class fix
- fix bug #903 `litepicker` with date range not having correct border
- page wrapper fix
- fix #900 `is-invalid-lite` class is not working under `was-validated` form class
- update `@tabler/icons` to version 1.48
- fix #960 - Badges not honoring font sizes
- fix #959 - `node-sass` does not properly compile nested media queries
- update package dependencies to newest version

## 1.0.0-beta5

**Tabler has finally lived to see dark mode! 🌝🌚**

- **Dark mode enabled!**
- add more cursors (#947)
- fix #892 - media queries need to be nested when negating
- update `@tabler/icons` to newest version
- move optional dependencies to peerDependencies (#924)
- move deployment to Github Actions (#934)
- table border fixes
- antialiased fix
- update `@tabler/icons` to version 1.42
- change default font to 'Inter'
- colors unify
- add `tom-select` and remove `choices.js`

## 1.0.0-beta4

- upgrade required node.js version to 14
- upgrade Bootstrap to 5.1
- upgrade dependencies
- fix #775 - litepicker not initializing
- fix `nouislider` import in dev

## 1.0.0-beta3

- upgrade Bootstrap to 5.0
- upgrade dependencies
- change `$border-radius-pill` variable
- badge vertical align fix

## 1.0.0-beta2

- update dependencies
- `li` marker fix
- page wrapper, nav fixes
- scripts optimize, remove `capture_once`
- `page-body` fixes
- layout navbar fix
- typography fix
- ribbon fix
- charts label fixes
- charts docs

## 1.0.0-beta

**Initial beta release of Tabler v1.0! Lots more coming soon though 😁**

- update Bootstrap to 5.0.0-beta2
- update other dependencies.
